using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Optimization : MonoBehaviour
{
    public GameObject[] activate;
    public GameObject[] deactivate;
    // Start is called before the first frame update
    void Awake()
    {
        foreach (GameObject obj in activate)
        {
            obj.SetActive(false);
        }

        foreach (GameObject obj in deactivate)
        {
            obj.SetActive(true);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    private void OnTriggerEnter(Collider other)
    {
        foreach (GameObject obj in activate)
        {
            obj.SetActive(true);
        }

        foreach (GameObject obj in deactivate)
        {
            obj.SetActive(false);
        }
    }
}
