using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class introFrameScript : MonoBehaviour
{
    public Color col;
    Image img;
    public float alphaSpeed = 1f;


    // Start is called before the first frame update
    void Start()
    {
        img = GetComponent<Image>();
        print(img.name);
        col = img.color;
    }

    // Update is called once per frame
    void Update()
    {
        FadeIn();
    }

    void FadeIn( )
    {
        //print("fadein");
        col.a += Time.deltaTime * alphaSpeed;
       img.color = col;
    }
}
