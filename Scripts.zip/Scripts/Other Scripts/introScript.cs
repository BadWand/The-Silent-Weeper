using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class introScript : MonoBehaviour
{
    public KeyCode skipKey = KeyCode.Space;
    public GameObject[] introFrames;
    [Header("Skip Values")]
    public float skipCounter;
    public float colorAlpha, alphaSpeed;
    // Start is called before the first frame update
    void Start()
    {
        skipCounter = 0;

    }
    // Update is called once per frame
    void Update()
    {
        Skip();
    }
    void Skip()
    {
        if (Input.GetKeyDown(skipKey))
        {
            skipCounter++;
        }

        for (int i = 0; i < introFrames.Length; i++)
        {
            if (skipCounter == i)
            {

                introFrames[i].SetActive(true);

                if (i == introFrames.Length - 1)
                {
                    if (Input.GetKeyDown(skipKey))
                    {
                        print("wow");
                        SceneManager.LoadScene("SampleScene");
                    }
                }
            }
            else if (skipCounter > i)
            {

                introFrames[i].SetActive(false);
            }

        }
    }
    

    

    
}
