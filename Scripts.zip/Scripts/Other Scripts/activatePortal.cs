using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class activatePortal : MonoBehaviour
{
    public GameObject portalBlocker;
    public GameObject portalSound;
    public GameObject particle;
    public GameObject[] additionalObjects;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Arrow")
        {
            portalBlocker.SetActive(false);
            portalSound.SetActive(true);
            particle.SetActive(true);

            try
            {
                foreach(GameObject additional in additionalObjects)
                {
                    additional.SetActive(true);
                }
            }
            catch (Exception e)
            {
                print("no additional objects");
            }
        }
    }
}
