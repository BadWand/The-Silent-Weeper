using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class TextSystem : MonoBehaviour
{
    public GameObject textFile;
    public float disableCountdown = 4f;
    bool abled;
    public static float x = 0;
        public float  xNew = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (x == 1)
        {
            customController.canJump = true;
        }
        if (abled)
        {
            disableCountdown -= Time.deltaTime;
            if (disableCountdown <= 0)
            {
                textFile.SetActive(false);
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            x = xNew;
            textFile.SetActive(true);
            abled = true;
        }
    }


}
