using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lookAtPlayer : MonoBehaviour
{
    Transform playerCamera;
    public GameObject[] trees;
    // Start is called before the first frame update
    void Start()
    {
        playerCamera = GameObject.FindGameObjectWithTag("MainCamera").transform;
    }

    // Update is called once per frame
    void Update()
    {
        
        foreach (GameObject tree in trees)
        {
            tree.transform.LookAt(playerCamera.position);

        }
    }
}
