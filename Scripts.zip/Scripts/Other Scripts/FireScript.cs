using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireScript : MonoBehaviour
{
    Light light_;
    [Space (10)]
    public float minRange, maxRange, minAngle, maxAngle, minIntensity, maxIntensity;
    [Space(10)]
    public float rangeChangeSpeed, angleChangeSpeed, intChangeSpeed;
    public bool changeRangeUp, changeRangeDown, changeAngle, changeIntensity;
    // Start is called before the first frame update
    void Start()
    {
        light_ = GetComponent<Light>();
    }


    
    // Update is called once per frame
    void Update()
    {
        Change();
        ChangeBools();       
    }

    

    void ChangeRange()
    {
        if (light_.range <= minRange)
        {
            print("should increase");
            light_.range += rangeChangeSpeed * Time.deltaTime;

        }
    }

    
    void Change()
    {
        if (light_.range <= minRange)
        {
            changeRangeUp = true;
            changeRangeDown = false;

        }
        else if (light_.range >= maxRange)
        {
            changeRangeDown = true;
            changeRangeUp = false;


        }
    }

    void ChangeBools()
    {
        if (changeRangeUp)
        {
            light_.range += rangeChangeSpeed * Time.deltaTime;

        }
    }
    void ChangeValues()
    {
        //range
        if (light_.range <= minRange)
        {
            //increase range
        }
        else if (light_.range >= maxRange)
        {
            //decrease range
            light_.range -= rangeChangeSpeed * Time.deltaTime;

        }
        //angle

        if (light_.spotAngle <= minAngle)
        {
            //increase angle
            light_.spotAngle += angleChangeSpeed * Time.deltaTime;


        }
        else if (light_.spotAngle >= maxAngle)
        {
            //decrease angle
            light_.spotAngle -= angleChangeSpeed * Time.deltaTime;

        }
        //intensity
        if (light_.intensity <= minIntensity)
        {
            //increase intens
            light_.intensity += intChangeSpeed * Time.deltaTime;

        }
        else if (light_.intensity >= maxIntensity)
        {
            //decrease intens
            light_.intensity -= intChangeSpeed * Time.deltaTime;

        }
    }
    

    
}
