using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemySpawnerScript : MonoBehaviour
{
    GameObject player;
    public GameObject[] enemies;
    public Transform[] spawnPoints;
    public float dist = 100f, spawnRate = 1f;
    public bool shouldSpawn;
    IEnumerator coroutine;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        coroutine = Spawn(spawnRate);
        StartCoroutine(coroutine);
    }

    // Update is called once per frame
    void Update()
    {
        CheckForSpawn();
    }

    void CheckForSpawn()
    {
        if (Vector3.Distance(this.transform.position, player.transform.position) < dist)
        {
            shouldSpawn = true;
        }
        else
        {
            shouldSpawn = false;
        }
    }

    private IEnumerator Spawn(float waitTime)
    {
        while (true)
        {
            print("now");
            int i = 0;
            if (shouldSpawn)
            {
                int index = Random.Range(0, spawnPoints.Length);
                print("spawn");
                Instantiate(enemies[i], spawnPoints[index].position, Quaternion.identity);
                if (enemies.Length < i)
                    i++;
                else if (enemies.Length >= i)
                    i = 0;
            }

            yield return new WaitForSeconds(waitTime);
        }
    }
}
