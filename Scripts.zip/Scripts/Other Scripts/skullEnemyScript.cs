using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class skullEnemyScript : MonoBehaviour
{
    Transform player;
    public float speed = 15f;
    MeshRenderer rend;
    Transform checkPointPos;
    public GameObject impactFX;
    public GameObject impactSound;
    public string checkpointPosName;
    public Collider[] colliders;
    [Header("Sounds")]
    public GameObject constantSound;
    public GameObject deadSound;
    
    // Start is called before the first frame update
    void Start()
    {
        colliders = GetComponentsInChildren<Collider>();
        checkPointPos = GameObject.Find(checkpointPosName).transform;
        player = GameObject.FindGameObjectWithTag("Player").transform;
        rend = GetComponentInChildren<MeshRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        LookAtPlayer();
    }

    private void FixedUpdate()
    {

        MoveTowardsPlayer();
        DestroyIfFar();

    }


    void DestroyIfFar()
    {
        if (Vector3.Distance(this.transform.position, player.transform.position) > 100f)
        {
            Destroy(this.gameObject);
        }
    }
    void LookAtPlayer()
    {
        transform.LookAt(player);
    }

    void MoveTowardsPlayer()
    {
        Vector3 a = transform.position;
        Vector3 b = player.position;
        transform.position = Vector3.MoveTowards(a,b, speed / 5);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Arrow")
        {
            foreach(Collider col in colliders)
            {
                col.enabled = false;
            }
            print("shot");
            constantSound.SetActive(false);
            deadSound.SetActive(true);
            rend.enabled = false;
            GameObject hitSound = (GameObject)Instantiate(impactSound, transform.position, Quaternion.identity);
            Destroy(hitSound, 2f);
            GameObject clone = (GameObject)Instantiate(impactFX, transform.position, Quaternion.identity);
            Destroy(clone, 1f);
            Destroy(other.gameObject, 0.1f);
            Destroy(this.gameObject, 1f);
        }
        else if (other.gameObject.tag == "Player")
        {
            player.position = checkPointPos.position;

            Destroy(this.gameObject, 1f);
        }
        
    }


}
