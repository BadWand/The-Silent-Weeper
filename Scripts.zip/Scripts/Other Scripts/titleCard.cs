using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class titleCard : MonoBehaviour
{
    public GameObject title;
    public GameObject fadeOut;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        Invoke("Title", 8f);
        Invoke("fade", 15f);
        Invoke("quittingTime", 20f);
    }

    void Title()
    {
        title.SetActive(true);
    }
    void fade()
    {
        fadeOut.SetActive(true);
    }

    void quittingTime()
    {
        Application.Quit();
    }

    
}
