using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wallRunScript : MonoBehaviour
{

    bool isOnGround;
    customController controller;
    [Header("Wall Checkers")]
    public LayerMask whatIsWall;
    public Transform rightWallChecker;
    public Transform leftWallChecker;
    public float wallDistance;
    bool wallOnRight, wallOnLeft;
    [Header("Wall Run Mechanics")]
    public bool isWallRunning;
    public float wallRunSpeed;
    public GameObject cam;
    Rigidbody rigby;
    [Header ("Wall Jump")]
    [SerializeField] KeyCode jumpKey = KeyCode.Space;
    public float _Force, _ForceDecrease;
    [SerializeField] float Force_Counter;
    public float wallJumpForce, wallJumpUp;
    private void Start()
    {
        controller = GetComponent<customController>();
        rigby = GetComponent<Rigidbody>();
        Force_Counter = _Force;
    }

    private void Update()
    {
        CheckForWalls();
        CheckIfOnGround();
        WallRunCamera();
        NewWallrun();
    }


    
    void CheckIfOnGround()
    {
        isOnGround = controller.Grounded;
    }

    void WallRunCamera()
    {
        if ((!isOnGround && wallOnRight) || (!isOnGround && wallOnLeft))
        { isWallRunning = true; }
        else
        {
            isWallRunning = false;
        }
        if (isWallRunning && wallOnRight)
        {
            cam.transform.localRotation = Quaternion.Euler(0, 0, 10);
        }
        else if (isWallRunning && wallOnLeft)
        {
            cam.transform.localRotation = Quaternion.Euler(0, 0, -10);

        }
        else
        {
            cam.transform.localRotation = Quaternion.Euler(0, 0, 0);

        }
    }

    void CheckForWalls()
    {

        wallOnRight = Physics.CheckSphere(rightWallChecker.position, wallDistance, whatIsWall);
        wallOnLeft = Physics.CheckSphere(leftWallChecker.position, wallDistance, whatIsWall);

    }

   

    void NewWallrun()
    {
        if (isWallRunning)
        {
            controller.DoubleJumpCounter = 0;
            rigby.velocity = new Vector3(rigby.velocity.x * wallRunSpeed, Force_Counter, rigby.velocity.z * wallRunSpeed); //set the y velocity while wallrunning
            Force_Counter -= _ForceDecrease * Time.deltaTime;
            if (rigby.velocity.x == 0)
            {
                Force_Counter = 0;
            }
            
        }
        else
        {
            Force_Counter = _Force;
        }

        if (Input.GetKeyDown(jumpKey) && customController.exitedWallrun)
        {

            rigby.velocity = transform.forward * wallJumpForce + transform.up * wallJumpUp;
            isWallRunning = false;
        }
    }


    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.layer == 7)
        {
            isWallRunning = false;
        }
    }


}
