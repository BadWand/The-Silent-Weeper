using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowShootScript : MonoBehaviour
{
    public GameObject arrowStandin;
    private GameObject arrowPrefab;
    public Transform arrowShootPoint;
    [Header("Arrow Force")]
    public float arrowForce;
    public float drawTime;
    public float coolDown;
    float counter = 0;
    [Header("Animation")]
    public Animator weaponAnimator;
    public bool reversing;
    // Start is called before the first frame update
    void Start()
    {
        arrowPrefab = Resources.Load("shootingArrow") as GameObject;
    }

    
    
    // Update is called once per frame
    void Update()
    {
        if (reversing)
        {
            weaponAnimator.SetFloat("drawMultiplier", -1f);
        }
        else
        {
            weaponAnimator.SetFloat("drawMultiplier", 1f);
        }
        if (Input.GetMouseButton(0))
        {
            ResetDraw();

            reversing = false;

            ShootCountDown();
        }
        if (Input.GetMouseButtonUp(0))
        {
            arrowStandin.SetActive(false);
            if (AnimationTranslator.stretching)
            {
                Shoot();
            }
            else
            {
                reversing = true;
            }
        }

    }
    void ResetDraw()
    {
        if(weaponAnimator.GetCurrentAnimatorStateInfo(0).normalizedTime <= 0)
        {
            weaponAnimator.ResetTrigger("drawn");

        }
    }
    
    void ShootCountDown()
    {

        weaponAnimator.SetTrigger("drawn");
            

        counter += Time.deltaTime;

            if (counter >= drawTime)
            {
                counter = drawTime;
            }
       


    }

   
    
    public void Shoot()
    {
        weaponAnimator.ResetTrigger("drawn");
        weaponAnimator.SetTrigger("shot");
       

        GameObject newArrow = (GameObject)Instantiate(arrowPrefab, arrowShootPoint.position, Quaternion.identity);
        Destroy(newArrow, 60f);
        Rigidbody rb = newArrow.GetComponent<Rigidbody>();
        rb.velocity = Camera.main.transform.forward * (arrowForce * (counter * 15f));

       
        counter = 0;
        
    }

    
}
