using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class customController : MonoBehaviour
{
    Rigidbody rigby;

    [Header("Movement")]
    public float walkSpeed = 9f;
    public float runSpeed = 14f;
    public float maxSpeed = 20f;
    public bool isWalking;
    float speed;


    [Header("Jump")]
    public float jumpForce = 30f;
    public float extraGravity = 45f;
    public bool Grounded;
    public Transform groundCheck;
    public float groundDistance = 0.2f;
    public LayerMask groundMask;
    public float DoubleJumpCounter;
    wallRunScript wallrun;
    public static bool canJump;
    public static bool exitedWallrun;


    [Header("Camera")]
    public float camRotationSpeed = 5f;
    public float cameraMinY = -60f, cameraMaxY = 75f;
    public Transform camera;
    public float rotationSmoothSpeed = 10f;
    float bodyRotationX,camRotationY;
    Vector3 directionIntentX, directionIntentY;
    public static bool rotatingPortal;

    [Header("Keybinds")]
    [SerializeField] KeyCode jumpKey = KeyCode.Space;
    [SerializeField] KeyCode sprintKey = KeyCode.LeftShift;

    [Header("Audio")]
    public GameObject grassWalk;
    public GameObject roomWalk;
    public GameObject StoneWalk;
    public GameObject landSound;
    public float audioSpeed = 1.2f;



    // Start is called before the first frame update
    void Start()
    {
        rigby = GetComponent<Rigidbody>();
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        wallrun = GetComponent<wallRunScript>();
    }

    // Update is called once per frame
    void Update()
    {
        LookRotation();
        Movement();
        ExtraGravity();
        CheckForGround();
        CounterDeterminer();
        if (Grounded)
        {
            exitedWallrun = false;
            if (DoubleJumpCounter == 2)
                Invoke("ResetCounter", 0.02f);
            
        }

      

        if (Input.GetKeyDown(jumpKey) && canJump)
            {
            
            
            Jump();
        }
        CheckIFWalking();

        //temp test key, delete later"
        if (Input.GetKeyDown(KeyCode.B))
        {
            canJump = true;
        }

    }


    
    

    void LookRotation()
    {
        if (!rotatingPortal)
        {
            bodyRotationX += Input.GetAxisRaw("Mouse X") * camRotationSpeed;
            camRotationY += Input.GetAxisRaw("Mouse Y") * camRotationSpeed;


            camRotationY = Mathf.Clamp(camRotationY, cameraMinY, cameraMaxY);

            Quaternion camTargetRotation = Quaternion.Euler(-camRotationY, 0, 0);
            Quaternion bodyTargetRotation = Quaternion.Euler(0, bodyRotationX, 0);

            transform.rotation = Quaternion.Lerp(transform.rotation, bodyTargetRotation,
                Time.deltaTime * rotationSmoothSpeed);

            camera.localRotation = Quaternion.Lerp(camera.localRotation, camTargetRotation,
                Time.deltaTime * rotationSmoothSpeed);

        }
    }

    void Movement()
    {
        directionIntentX = camera.right;
        directionIntentX.y = 0;
        directionIntentX.Normalize();

        directionIntentY = camera.forward;
        directionIntentY.y = 0;
        directionIntentY.Normalize();

        rigby.velocity = directionIntentY * Input.GetAxisRaw("Vertical") * speed +
            directionIntentX * Input.GetAxisRaw("Horizontal") * speed +
            Vector3.up * rigby.velocity.y;

        rigby.velocity = Vector3.ClampMagnitude(rigby.velocity, maxSpeed);

        if (Input.GetKey(sprintKey))
        {
            speed = runSpeed;
        }
        else
            if (!Input.GetKey(sprintKey))
        {
            speed = walkSpeed;
        }
    }


    void CheckIFWalking()
    {
        if (rigby.velocity.x != 0 ||rigby.velocity.z != 0)
        {
            isWalking = true;
        }
        else
        {
            isWalking = false;
        }
    }
    void ExtraGravity()
    {
        rigby.AddForce(Vector3.down * extraGravity);
    }

    void CheckForGround()
    {
        Grounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);
    }

    void CounterDeterminer()
    {
        if (Grounded)
        {
            ResetCounter();

        }
        else if (wallrun.isWallRunning)
        {
            DoubleJumpCounter = 1;
        }
    }
    void Jump()
    {

        if (DoubleJumpCounter == 0 && Grounded && !wallrun.isWallRunning)
        {
            
                rigby.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
                print("regular jump");
                DoubleJumpCounter = 2;
            

        }
        else if (DoubleJumpCounter == 1 && exitedWallrun)
        {
            rigby.AddForce(Vector3.up * jumpForce * 1.5f, ForceMode.Impulse);
            print("coyote jump");
            DoubleJumpCounter = 2;

        }





    }

    void ResetCounter()
    {
        if (Grounded)
            DoubleJumpCounter = 0;
    }

    private void OnCollisionStay(Collision collision)
    {
        if (isWalking)
        {
            if (collision.gameObject.tag == "Grass")
            {
                
                    roomWalk.SetActive(false);

                    grassWalk.SetActive(true);
                
             

                if (Input.GetKey(sprintKey) ||wallrun.isWallRunning)
                {
                    grassWalk.GetComponent<AudioSource>().pitch = audioSpeed;
                }
                else
                {

                    grassWalk.GetComponent<AudioSource>().pitch = 1f;

                }
            }
            else if (collision.gameObject.tag == "RoomGround")
            {
                
                    grassWalk.SetActive(false);

                    roomWalk.SetActive(true);
                
                

                if (Input.GetKey(sprintKey) || wallrun.isWallRunning)
                {
                    roomWalk.GetComponent<AudioSource>().pitch = audioSpeed;
                }
                else
                {

                    roomWalk.GetComponent<AudioSource>().pitch = 1f;

                }
            }
            else if (collision.gameObject.tag == "Solid")
            {

                grassWalk.SetActive(false);

                roomWalk.SetActive(false);
                StoneWalk.SetActive(true);



                if (Input.GetKey(sprintKey) || wallrun.isWallRunning)
                {
                    StoneWalk.GetComponent<AudioSource>().pitch = audioSpeed;
                }
                else
                {

                    StoneWalk.GetComponent<AudioSource>().pitch = 1f;

                }
            }
        }
        else
        {
            grassWalk.SetActive(false);
            roomWalk.SetActive(false);
            StoneWalk.SetActive(false);

        }

    }
    private void OnCollisionEnter(Collision collision)
    {
        if (wallrun.isWallRunning)
        {
            exitedWallrun = false;

            DoubleJumpCounter = 1;
        }

        if (collision.gameObject.tag == "Solid")
        {
            StoneWalk.SetActive(true);
            GameObject clone = (GameObject)Instantiate(landSound, transform.position, Quaternion.identity);
            Destroy(clone, 3f);
        }
    }
    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.layer == 6)
        {
            exitedWallrun = true;
            DoubleJumpCounter = 1;
        }
        if (collision.gameObject.tag == "Solid")
        {
            StoneWalk.SetActive(false);
        }
        if (collision.gameObject.tag == "Grass")
        {
            grassWalk.SetActive(false);
        }
    }

}
