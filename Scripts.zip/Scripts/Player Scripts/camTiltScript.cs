using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camTiltScript : MonoBehaviour
{


    [Header("Tilt")]
    public float minZ = -13f;
    public float maxZ = 13f;
    public float defaultZ = 0f;

    [Header("Keybinds")]
    public KeyCode L_Tilt = KeyCode.Z;
    public KeyCode R_Tilt = KeyCode.C;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetKey(L_Tilt))
        {
            TiltLeft();
        }
        if (Input.GetKeyUp(L_Tilt))
        {
            print("stop left");
        }
    }


    void TiltLeft()
    {
        print("tilt left");
    }

    void TiltRight()
    {

    }
}
