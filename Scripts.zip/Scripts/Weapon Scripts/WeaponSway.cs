using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponSway : MonoBehaviour
{
    public float value, maxAmount, smoothValue;
    Vector3 firstPos;
    // Start is called before the first frame update
    void Start()
    {
        firstPos = transform.localPosition;
    }

    // Update is called once per frame
    void Update()
    {
        float x = -Input.GetAxis("Mouse X") * value;
        float y = -Input.GetAxis("Mouse Y") * value * 2;
        x = Mathf.Clamp(x, -maxAmount, maxAmount);
        y = Mathf.Clamp(y, -maxAmount, maxAmount);
        Vector3 lastPos = new Vector3(x, y, 0);
        transform.localPosition = Vector3.Lerp(transform.localPosition, 
            lastPos + firstPos, Time.deltaTime * smoothValue);
    }
}
