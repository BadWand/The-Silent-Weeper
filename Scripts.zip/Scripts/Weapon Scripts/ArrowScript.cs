using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowScript : MonoBehaviour
{
    Rigidbody rigby;
    public bool moving;
    public GameObject impactSound;
    public GameObject trail, portalTrail;
    public GameObject particle;
    [Header("Portal")]
    public int layerMask;
    public float extraX, extraY, extraZ;
    [Space(40)]
    public float extraX_2;
    public float extraY_2;
    public float extraZ_2;
    private void Awake()
    {
        moving = true;

    }
    // Start is called before the first frame update
    void Start()
    {
        layerMask = LayerMask.GetMask("Teleporter");
        rigby = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        Teleport();
        if (moving)
            transform.rotation = Quaternion.LookRotation(rigby.velocity * -1);
    }


    private void OnCollisionEnter(Collision collision)
    {
        moving = false;
        rigby.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;
        rigby.isKinematic = true;
        Invoke("PlaySound", .1f);
        Invoke("SetInactive", 30f);
        particle.SetActive(true);


    }

   

    void Teleport()
    {
        Vector3 rayVector;
        RaycastHit hit;
        if (Physics.Raycast (transform.position, Vector3.forward, out hit, 2, layerMask))
        {
            portalTrail.SetActive(true);

            trail.SetActive(false);
            print(hit.transform.gameObject.name);
            print(hit.point + " point");
            rayVector = hit.point;
             print(rayVector + "vector");
             print(hit.transform.position + " transform");
                transform.position = new Vector3(rayVector.x + hit.transform.GetComponent<childPortal>().extraX_Arrow, rayVector.y +
                  hit.transform.GetComponent<childPortal>().extraY_Arrow, rayVector.z + hit.transform.GetComponent<childPortal>().extraZ_Arrow);

            impactSound.GetComponent<AudioSource>().spatialBlend = 0;
            impactSound.GetComponent<AudioSource>().volume = 0.5f;
        }


    }

    void PlaySound()
    {
        impactSound.SetActive(true);

    }
    void SetInactive()
    {
        this.gameObject.SetActive(false);
    }

   
}
