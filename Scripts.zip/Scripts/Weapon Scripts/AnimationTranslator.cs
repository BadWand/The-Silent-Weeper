using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationTranslator : MonoBehaviour
{
    [Header("Sounds")]
    public GameObject stringSound;
    public GameObject shootSound;
    public GameObject reloadSound;
    public GameObject activationSound;
    [Header("Other")]
    public ArrowShootScript arrowScr;
    public GameObject arrowStandin;
    public MeshRenderer arrowRenderer, arrowHeadRenderer;
    Animator anim;
    [Header("Bools")]
    public static bool stretching;
    [Header ("FOV")]
    public Camera MainCamera;
    public float FOV_Max = 80, FOV_Min, FOV_Speed;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        arrowScr = GameObject.FindObjectOfType<ArrowShootScript>();
        MainCamera.fieldOfView = FOV_Max;
    }

    // Update is called once per frame
    void Update()
    {
        if (stretching)
        {
            if (Input.GetMouseButton(1))
                FOVDecrease();
            else
                FOVIncrease();
        }
        else if (!stretching)
        {
            FOVIncrease();
        }
    }


    void FirstActivation()
    {
        activationSound.SetActive(true);
    }
    void FOVIncrease()
    {
        if (MainCamera.fieldOfView < FOV_Max)
        {
            MainCamera.fieldOfView += (FOV_Speed * 3) * Time.deltaTime;
        }
        else if (MainCamera.fieldOfView >= FOV_Max)
        {
            MainCamera.fieldOfView = FOV_Max;
        }
    }

    void FOVDecrease()
    {
        if (MainCamera.fieldOfView > FOV_Min)
        {
            MainCamera.fieldOfView -= FOV_Speed * Time.deltaTime;
        }
        else if (MainCamera.fieldOfView <= FOV_Min)
        {
            MainCamera.fieldOfView = FOV_Min;
        }

    }
    void ReloadEvent()
    {
        reloadSound.SetActive(true);
        shootSound.SetActive(false);

    }
    void StringSoundEvent()
    {
        stretching = true;
        stringSound.SetActive(true);
        activationSound.SetActive(false);

    }

    void ActualShooting()
    {
        stretching = false;
        arrowRenderer.enabled = false;
        arrowHeadRenderer.enabled = false;

    }

    void ActualDrawing()
    {
        arrowRenderer.enabled = true;
        arrowHeadRenderer.enabled = true;
    }

    void ShootSoundEvent()
    {

        shootSound.SetActive(true);
        stringSound.SetActive(false);
        reloadSound.SetActive(false);
       
    }
}
